package t38.kafkahandson.experiment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExperimentApplicationTests {

	@Test
	void contextLoads() {
	}

}
